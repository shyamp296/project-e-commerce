const path = require('path')
const User = require('../models/user_model')
// const service = require('../models/service_model')


exports.dashbord = (async (req, res) => {
  res.render('home', {
    pagetitle: 'Home',
    path: '/home',
    role :role
  })
  
})

