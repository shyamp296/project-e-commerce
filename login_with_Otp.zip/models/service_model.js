const mongoose = require('mongoose')

const Schema = mongoose.Schema

const serviceSchema = new Schema({

    vehicle_no: {
        type: String,
    },
    Pickup_date: {
        type: Date,

    },
    Drop_date: {
        type: Date,
        required: true
    },
    location: {
        type: String,
        required: true
    },
    Price: {
        type: Number,
        required: true
    },
    userId : {
        type : Schema.Types.ObjectId,
        ref : 'user',
        required : true
    }




})

module.exports = mongoose.model('services', serviceSchema)
