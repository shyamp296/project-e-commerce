const path = require('path')


const express = require('express')

const router = express.Router()

const serviceModel = require('../models/service_model')

const userController = require('../controller/user_Controller')
const adminController = require('../controller/admin_controller')


const auth = require('../middleware/auth')



router.get('/admin',auth,  adminController.dashbord)
router.get('/add-service',auth, adminController.addService)
router.post('/add-service', auth, adminController.postaddService)
router.post('/Payment', auth , adminController.postPayment)
router.get('/Payment', auth, adminController.makePayment)


module.exports = router