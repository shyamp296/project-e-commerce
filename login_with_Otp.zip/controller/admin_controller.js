const User = require('../models/user_model')
const service = require('../models/service_model')
const stripe = require('stripe')('sk_test_51MgLCXSDr4JMwduY2oavfpijCS8x40d4EXfh2tZxef7iVBIYvbWI681IbJ7mtP1eezbFYQxmrOVrgnb79prRMxmn009gbLMman')
const nodemailer = require('nodemailer')

// transporter for the mail
const trasporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {

        user: 'sdpatel320@gmail.com',
        pass: 'xkqmdiatqzbrzuue'
    }
})

// get sevices on the admin dashboard
exports.dashbord = async (req, res, next) => {

    const user = await User.findOne({ _id: id })
    const services = await service.aggregate([{
        $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "us"
        }
    }])
    res.render('services', {
        pagetitle: 'Services',
        user,
        services
    })

    console.log(services);
}

// get add sevices 
exports.addService = (req, res, next) => {

    User.find({ role: 2 }).then((user) => {
        console.log(user);
        res.render('add_service', {
            pagetitle: 'add service',
            user
        })
    })
}

//posst add service
exports.postaddService = async (req, res, next) => {

    const { userId, vno, pdate, ddate, location, Price } = req.body
    const Service = new service({
        vehicle_no: vno,
        Pickup_date: pdate,
        Drop_date: ddate,
        location: location,
        Price: Price,
        userId: userId
    })

    const existingUser = await User.findOne({ _id: userId })
    Service.save().then((result) => {
        trasporter.sendMail({
            to: existingUser.email,
            from: 'sdpatel320@gmail.com',
            subject: 'Service Generated',
            html: `<h1>your service has been successfully genrated</h1>`
        }).then(() => {
            console.log(result);

            res.redirect('/admin')
        })
    })

}

exports.makePayment = (req, res, next) => {

    res.render('checkOut', {
        pagetitle: 'checkOut'
    })

}

exports.postPayment = async (req, res, next) => {

    const { title, amount } = req.body
    const session = await stripe.checkout.sessions.create({

        payment_method_types: ['card'],
        line_items: [
            {
                price_data: {

                    currency: "INR",
                    product_data: {

                        name: title,

                    },
                    unit_amount: amount * 100
                },
                quantity: 1,
            },
        ],
        mode: "payment",
        success_url: 'http://localhost:5000/sign-In',
        cancel_url: 'http://localhost:5000/html/cancle.html',

    })


    res.redirect(303, session.url);
}