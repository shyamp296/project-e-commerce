const path = require('path')
// const User = require('../models/user_model')
// const service = require('../models/service_model')


exports.dashbord = (async(req ,res) => {
    // const users = await User.find({_id : id})
    // const services = await service.find({ userId: id })
    res.render('home',{
        pagetitle : 'Home'
        // user : users,
        // services : services
    })
    
})