const path = require('path')
const User = require('../models/user_model')
const Product = require('../models/product_model')



exports.dashbord = (async (req, res, next) => {
  res.render('home', {
    pagetitle: 'Home',
    path: '/home',
    role: role
  })
  next();
})

exports.getproductDetails = (async (req, res, next) =>{
  const id = req.query.id
  const product = await Product.findById(id)
  res.render('product/productDetail', {
    pagetitle : 'Product Details',
    role : role,
    product


  })
})

