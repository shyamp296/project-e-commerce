const User = require('../models/user_model')
const stripe = require('stripe')('sk_test_51MgLCXSDr4JMwduY2oavfpijCS8x40d4EXfh2tZxef7iVBIYvbWI681IbJ7mtP1eezbFYQxmrOVrgnb79prRMxmn009gbLMman')
const nodemailer = require('nodemailer')

// transporter for the mail
const trasporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {

        user: 'sdpatel320@gmail.com',
        pass: 'xkqmdiatqzbrzuue'
    }
})

// get product management
exports.productManagement = async (req, res) => {

    res.render('productManagement/displayProduct',{
        pagetitle : 'Product Management',
        role : role
    })
}
// get add Product
exports.getAddProduct = async (req, res) => {

    res.render('addProduct' ,{
        pagetitle : 'add product'
        
    })
}


// // get Payment
// exports.makePayment = (req, res, next) => {

//     res.render('checkOut', {
//         pagetitle: 'checkOut'
//     })

// }


// //post Payment
// exports.postPayment = async (req, res, next) => {

//     const { title, amount } = req.body
//     const session = await stripe.checkout.sessions.create({

//         payment_method_types: ['card'],
//         line_items: [
//             {
//                 price_data: {

//                     currency: "INR",
//                     product_data: {

//                         name: title,

//                     },
//                     unit_amount: amount * 100
//                 },
//                 quantity: 1,
//             },
//         ],
//         mode: "payment",
//         success_url: 'http://localhost:5000/sign-In',
//         cancel_url: 'http://localhost:5000/html/cancle.html',

//     })


//     res.redirect(303, session.url);
// }