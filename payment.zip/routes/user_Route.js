const path = require('path')




const express = require('express')

const router = express.Router()

// const userModel = require('../models/user_model')
const userController = require('../controller/user_Controller')

const auth = require('../middleware/auth')



router.get('/', auth, userController.dashbord)
router.get('/add-customer', auth, userController.addCustomer)
router.post('/add-customer', auth, userController.postAddCustomer)

// update Customer
router.get('/getupdateCustomer',auth , userController.updateCustomer)
router.post('/postupdateCustomer',auth , userController.postupdateCustomer)

// delete Customer
router.get('/deleteCustomer', auth, userController.deleteCustomer)
router.get('/services', auth, userController.getServices)

// add sevices
router.get('/add-service', auth, userController.getAddService)
router.post('/padd-service', auth, userController.postAddService)

// update service
router.get('/getupdateService', auth, userController.updateService)
router.post('/postupdateService', auth, userController.postupdateService)

// delete service
router.get('/deleteService', auth, userController.deleteService)

// make payment
router.post('/payment',auth , userController.postPayment)


module.exports = router