const mongoose = require('mongoose')
var DateOnly = require('mongoose-dateonly')(mongoose);


const Schema  = mongoose.Schema

const userSchema  = new Schema({
    Fullname : {
        type: String,
        required : true 
    },
    email : {
        type : String,
        required : true
    },
    Password :{
        type : String,
        required : true
    },
    phone : {
        type : Number,
        required : true
    },
    DOB : {
        type: DateOnly,
        required : true
    },
    city : {
        type : String,
        required : true
    },
    role : {
        type : String,
        required : true
    }
}
)

module.exports = mongoose.model('User', userSchema)