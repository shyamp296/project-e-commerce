const mongoose = require('mongoose')
var DateOnly = require('mongoose-dateonly')(mongoose);

const Schema = mongoose.Schema

const customerSchema = new Schema({
    Fullname: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    DOB: {
        type: DateOnly,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'user',
        required: true
    }

}
)

module.exports = mongoose.model('customer', customerSchema)