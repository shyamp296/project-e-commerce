const mongoose = require('mongoose')
var DateOnly = require('mongoose-dateonly')(mongoose);

const Schema = mongoose.Schema

const serviceSchema = new Schema({

    vehicle_no: {
        type: String,
    },
    Pickup_date: {
        type: DateOnly,

    },
    Drop_date: {
        type: DateOnly,
        required: true
    },
    location: {
        type: String,
        required: true
    },
    Price: {
        type: Number,
        required: true
    },
    customerId : {
        type : Schema.Types.ObjectId,
        ref: 'customer',
        required : true
    }




})

module.exports = mongoose.model('services', serviceSchema)
