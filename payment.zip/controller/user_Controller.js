const path = require('path')
const User = require('../models/user_model')
const service = require('../models/service_model')
const customer = require('../models/customer_model')
const stripe = require('stripe')('sk_test_51MgLCXSDr4JMwduY2oavfpijCS8x40d4EXfh2tZxef7iVBIYvbWI681IbJ7mtP1eezbFYQxmrOVrgnb79prRMxmn009gbLMman')
const { response } = require('express')

//get dashboard
exports.dashbord = async (req, res, next) => {
   
   
    const customers = await customer.find({ userId : id})
        res.render('home',{
            pagetitle: 'Dashboard',
            customers,
            id,
            role
        }
    )
}

//add customer 
exports.addCustomer = async (req, res, next) => {

    res.render('addCustomer', {
        pagetitle: 'Add Customer'
    })
}

//post add customer
exports.postAddCustomer = async (req, res, next) => {
  
    const { Fullname, email, phone, DOB, city,userId } = req.body
    console.log(req.body);

    const customers = new customer({
        Fullname,
        email,
        phone,
        DOB,
        city,
        userId
    })
    await customers.save().then( ()=> { 
        res.redirect('/')
    })
}

// get Update Customer
exports.updateCustomer = async (req, res, next) => {
    const cid = req.query.id
    customer.findById(cid).then( (customers) => {

        res.render('updateCustomer', {
            pagetitle: 'Update Customer',
            customers
        })
    })
}

//post update customer
exports.postupdateCustomer = async (req, res, next) => {
    const { Fullname, email, phone, DOB, city,userId,id } = req.body
    customer.findById(id).then((customer)=>{
        customer.Fullname = Fullname
        customer.email = email
        customer.phone = phone
        customer.DOB = DOB
        customer.city = city
        customer.userId = userId

        return customer.save()

    }).then( (customers) => {
        console.log(customers);
        res.redirect('/')
    })
}

// delete Customer
exports.deleteCustomer = async (req, res, next) => {
    const id = req.query.id
    customer.deleteOne({ _id: id }).then(() => {
        console.log('delete successfully');
        res.redirect('/')
    })
}

//get services 

exports.getServices = async (req, res, next) => {
    
    const id = req.query.id
    console.log(id);
    const services = await service.find({customerId : id})
    res.render('services',{
        pagetitle: 'Services',
        services,
    
    })

}

// get add service

exports.getAddService = async (req, res, next) =>{
   
    const customers = await customer.find({ userId: id })
    res.render('addServices',{
        pagetitle: 'Add Service',
        customers
    })
}

//post add service
exports.postAddService = async (req, res, next) =>{
    const { vehicle_no, Pickup_date, Drop_date, location, Price, customerId } = req.body
    console.log(req.body.customerId);
    const services = new service({
        vehicle_no,
        Pickup_date,
        Drop_date,
        location,
        Price,
        customerId
    })

    services.save().then((r) =>{
        console.log(r);
        res.redirect('/')
    })
}

//get update service
exports.updateService = async (req, res, next) =>{
    const id = req.query.id

    service.findById(id).then((service)=>{

        res.render('updateService',{
            pagetitle: 'Update Service',
            service,
            id
        })

    })

}

//post update service
exports.postupdateService = async (req, res, next) =>{
    const { vehicle_no, Pickup_date, Drop_date, location, Price, customerId,id } = req.body
    service.findById(id).then((service)=>{
        service.vehicle_no = vehicle_no
        service.Pickup_date = Pickup_date
        service.Drop_date = Drop_date
        service.location = location
        service.Price = Price
        service.customerId = customerId

        return service.save()

    }).then( (services) => {
        console.log(services);
        res.redirect('/')
    })
}

//delete service
exports.deleteService = async (req, res, next) =>{
    const id = req.query.id
    service.deleteOne({ _id: id }).then(() => {
        console.log('delete successfully');
        res.redirect('/')
    })
}

//post payment
exports.postPayment = async (req, res, next) => {

    const { VehicleNo, amount } = req.body
    const session = await stripe.checkout.sessions.create({

        payment_method_types: ['card'],
        line_items: [
            {
                price_data: {

                    currency: "INR",
                    product_data: {

                        name: VehicleNo,

                    },
                    unit_amount: amount * 100
                },
                quantity: 1,
            },
        ],
        mode: "payment",
        success_url: 'http://localhost:9000/',
        cancel_url: 'http://localhost:9000/html/cancle.html'

    })


    res.redirect(303, session.url);
}