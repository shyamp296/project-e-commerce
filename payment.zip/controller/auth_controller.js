const bcrypt = require('bcrypt')
const nodemailer = require('nodemailer')
const jwt = require('jsonwebtoken')
const User = require('../models/user_model')
const otpverification = require('../models/otpverification_model')
const multer = require('multer')
const path = require('path')

const SECRET_KEY = "Shyamdadhaniya"

// transporter for the mail
const trasporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {

        user: 'sdpatel320@gmail.com',
        pass: 'xkqmdiatqzbrzuue'
    }
})

// Get login
exports.getlogin = ((req, res, next) => {
    res.render('login', {
        pagetitle: 'Login'
    })
})

//Get registration 
exports.getregister = ((req, res, next) => {
    res.render('registration', {
        pagetitle: 'registration'
    })
})

//Post registration
exports.addUser = async (req, res, next) => {
    const { Fullname, email, city, phone, DOB, password,role } = req.body
    // const image = req.file
    try {
        const existinguser = await User.findOne({ email: email })
        if (existinguser) {
            console.log('email is already exist');
            return res.redirect('/registration')
        }
        
        const hashedPassword = await bcrypt.hash(password, 12)


        const user = new User({
            Fullname: Fullname,
            email: email,
            Password: hashedPassword,
            city: city,
            phone : phone,
            DOB : DOB,
            role : role
        })



        user.save().then((result) => {
            console.log(result);
            res.redirect('/sign-In')

        }).catch((err) => {
            console.log(err)
        });
    } catch (error) {
        console.log(error);
    }
}

//Post sign-In
exports.signIn = async (req, res, next) => {

   const { email,password } = req.body

    console.log(email);
    try {

        const existingUser = await User.findOne({ email: email })
        if (!existingUser) {
            console.log('user not found');
            return res.redirect('/registration')
        }

        const matchpassword = await bcrypt.compare(password, existingUser.Password)
        if (!matchpassword) {
            console.log('Password is incorrect');
            return res.redirect('/sign-In')
        }

        const otp = `${Math.floor(1000 + Math.random() * 9000)}`
        console.log(otp);
        const hashedotp = await bcrypt.hash(otp, 12)

        const Otpverification = await new otpverification({
            userId: existingUser._id,
            otp: hashedotp,
            createdAt: Date.now(),
            expiresAt: Date.now() + 360000,
        })

        await Otpverification.save()
        trasporter.sendMail({
            to: existingUser.email,
            from: 'sdpatel320@gmail.com',
            subject: 'Otp verification',
            html: `<h1>Your verification otp is ${otp}.</h1>`
        }).then(() => {
            res.render('otpverification', {
                pagetitle: 'Otp Verification',
                existingUser
            })
        })


    } catch (error) {

        console.log(error);
    }
}

//Post OTP verification
exports.postOtpVerification = async (req, res, next) => {
    try {
        const { id, otp } = req.body
        const existingUser = await User.findOne({ _id: id })
        const existingotp = await otpverification.findOne({ userId: id })
        if (existingotp) {

            if (existingotp.expiresAt < Date.now()) {

                 await otpverification.deleteMany({ userId: id })
                console.log('your otp has been expies please login again');
                res.redirect('/sign-In')

            } else {
                const validOtp = await bcrypt.compare(otp, existingotp.otp)
                if (validOtp) {
                    
                    await otpverification.deleteMany({ userId: id })
                    const token = jwt.sign({ id: existingUser._id ,role : existingUser.role }, SECRET_KEY)
                    console.log(existingUser.role);
                    res.cookie('token', token, {
                        httpOnly: true,
                        maxAge: 40000000000


                    })
               
                        console.log('heloo i am customer')
                        return res.redirect('/')
                } else {

                    res.render('otpverification', {
                        pagetitle: 'Otp Verification',
                        existingUser
                    })
                }
            }
        } else {

            console.log('otp has not found please request again');
            res.redirect('/sign-In')
        }


    } catch (error) {

    }
}

// get signed out
exports.signOut = async (req, res, next) => {

    res.clearCookie("token")
    res.redirect('/sign-In')
}


//get forget password
exports.getforgetPassword = (req, res, next) => {

    res.render('forgetPassword', {
        pagetitle: 'Forget-Password'
    })
}

//post forget password
exports.postforgetPasword = async (req, res, next) => {

    const email = req.body.email

    const user = await User.findOne({ email: email })
    if (user) {
        console.log(user);

        // const token = jwt.sign('ftoken', token , { 
        //     maxAge : 4000,
        //     http : true
        // })
        // res.render('resetPassword',{
        //     pagetitle : 'Reset-password',
        //     user
        // })

        trasporter.sendMail({
            to: email,
            from: 'sdpatel320@gmail.com',
            subject: 'Reset your password',
            html: `<p>Click <a href=http://localhost:5000/reset-password/${user._id}>here</a> to reset your password</p>`
        }).then(ress => {
            res.redirect('/sign-In')
            console.log('sent');
        })
    } else {

        res.redirect('/forget-password')
    }

}

// get reset password
exports.getresetPassword = (req, res, next) => {
    const id = req.params.id
    res.render('resetPassword', {
        pagetitle: 'Reset-password',
        id
    })
}

// post reset password 
exports.postresetPassword = async (req, res, next) => {

    const id = req.body.id
    const password = req.body.password

    const hashedPassword = await bcrypt.hash(password, 12)
    const user = await User.findOne({ _id: id })
    if (user) {
        user.Password = hashedPassword

        user.save().then(result => {
            res.redirect('/sign-In')
        })
    }

}


