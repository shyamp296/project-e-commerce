const User = require('../models/user_model')
const service = require('../models/service_model')
const stripe = require('stripe')('sk_test_51MgLCXSDr4JMwduY2oavfpijCS8x40d4EXfh2tZxef7iVBIYvbWI681IbJ7mtP1eezbFYQxmrOVrgnb79prRMxmn009gbLMman')
const nodemailer = require('nodemailer')

// transporter for the mail
const trasporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {

        user: 'sdpatel320@gmail.com',
        pass: 'xkqmdiatqzbrzuue'
    }
})

// get sevices on the admin dashboard
exports.dashbord = async (req, res, next) => {

    const user = await User.find({role : 2})
    res.render('User', {
        pagetitle: 'Users',
        user

    })

    console.log(user);
}

exports.getaddUser = async (req, res, next) => {
    res.render('addUser',{
        pagetitle : 'Add User'
    })

}

exports.postaddUser = async (req , res ,next) =>{
    
}

