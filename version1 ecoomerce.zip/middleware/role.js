const jwt = require('jsonwebtoken')
const User = require('../models/user_model')


const SECRET_KEY = "Shyamdadhaniya"

const role = (res, req, next) => {


    try {

        const token = res.cookies.token
        if (token) {
            const users = jwt.verify(token, SECRET_KEY)


            req.users = users

            id = users.id
            
      
           

            next()

        } else {
            role = 0

            next()
        }
    } catch (error) {

        console.log(error);
    }
}

module.exports = role