const path = require('path')
const User = require('../models/user_model')
const Product = require('../models/product_model')



exports.dashbord = (async (req, res, next) => {
  const Tproduct = await Product.find({ product_type: "t-shirt", product_category : "male" }).limit(6)
  const Sproduct = await Product.find({ product_type: "shirt" })
 
  const WWproduct = await Product.find({ product_type: "Western Wear" })
  const WSproduct = await Product.find({ product_type: "Saree" })



  res.render('home', {
    pagetitle: 'Home',
    path: '/home',
    role: role,
    Tproduct,
    Sproduct,
    WWproduct,
    WSproduct
  })
  next();
})

exports.getproductDetails = (async (req, res, next) =>{
  const id = req.query.id
  const product = await Product.findById(id)
  res.render('product/productDetail', {
    pagetitle : 'Product Details',
    role : role,
    product


  })
})

exports.getCart = (req, res, next) => {
  let totalPrice = 0;

  user
    .populate('cart.items.productId')
    // .execPopulate()
    .then(user => {
      const products = user.cart.items;
      for (let i = 0; i < products.length; i++) {
        totalPrice = totalPrice + products[i].price;
      }

      //Set Cookie totalPrice = totalPrice  
      res.cookie('totalPrice', totalPrice, { httpOnly: true })
      res.render('product/cart',
        {
          totalPrice: totalPrice,
          products: products,
          pagetitle: 'Cart',
         
          
        });
    })
    .catch(err => console.log(err));
};

exports.postCart = (req, res, next) => {
  const productId = req.body.productId;

  Product.findById(productId)
    .then(product => {
      return req.user.addToCart(product);
    })
    .then(result => {
      res.redirect('/cart');
    })
    .catch(err => console.log(err));
};

exports.postDeleteCartItem = (req, res, next) => {
  const productId = req.body.productId;
  req.user
    .removeFromCart(productId)
    .then(result => {
      res.redirect('/cart');
    })
    .catch(err => console.log(err));
}